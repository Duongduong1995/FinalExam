$(function(){
    $(".header").load("templates/header.html"); 
    $(".main").load("templates/main.html"); 
    $(".footer").load("templates/footer.html"); 
  });

// đi đến trang chủ
function viewHome(){
  $(".main").load("templates/main.html"); 
}

function viewUser(){
  $(".main").load("user/main.html", function(){
    initTable();
  }); 
}


//khởi tạo dữ liệu cho bảng
function User(id, groupname, member, name, creator, createdate){
    this.id = id;
    this.groupname = groupname;
    this.member = member;
    this.name = name;
    this.creator = creator;
    this.createdate = createdate;
}
 
 

//khởi tạo danh sách cho bảng nhân viên
function initTable(){
  $('tbody').empty();
  $.ajax({
    url: 'https://62163dbb7428a1d2a3605db6.mockapi.io/api/v1/users/',
    type: 'GET', 
    success:function(result){
        result.forEach(function(item){
          $('tbody').append(
            '<tr>'+
                '<td>'+ item.id +'</td>'+
                '<td>'+ item.groupname +'</td>'+
                '<td>'+ item.member +'</td>'+
                '<td>'+ item.name +'</td>'+
                '<td>'+ item.creator +'</td>'+
                '<td>'+ item.createdate +'</td>'+
                '<td>'+
                    '<a class="edit" title="Edit" data-toggle="tooltip" onclick ="opendUpdateModal('+ item.id +')"><i class="material-icons">&#xE254;</i></a>'+
                    '<a class="delete" title="Delete" data-toggle="tooltip" onclick ="deleteUser('+ item.id +')"><i class="material-icons">&#xE872;</i></a>'+
                    '<a class="refresh" title="Refresh" data-toggle="tooltip" onclick ="viewUser('+ item.id +')"><i class="fa-solid fa-arrows-rotate"></i>'+
                '</td>'+
            '</tr>'
          )
        }); 
    }
  }); 
}

function openAddNewModal(){
  $("#myModal").modal("show");
  reset();
}

function hideAddNewModal(){
  $("#myModal").modal("hide");
}

function createNewUser(){
    var groupname = document.getElementById("groupname").value;
    var member = document.getElementById("member").value;
    var name = document.getElementById("name").value;
    var creator = document.getElementById("creator").value;
    var createdate = document.getElementById("createdate").value;
  
    var user = {
      groupname: groupname,
      member: member,
      name: name,
      creator: creator,
      createdate: createdate

    }
    // gọi api thêm mới nhân viên
    $.ajax({
      url: 'https://62163dbb7428a1d2a3605db6.mockapi.io/api/v1/users/',
      type: 'POST',
      data: user,
      async : false,    
      success:function(result){
      }
    });
  
    initTable();
    hideAddNewModal();
}

function opendUpdateModal(userId){
    openAddNewModal();
     // gọi api lấy nhân viên theo id
     $.ajax({
      url: 'https://62163dbb7428a1d2a3605db6.mockapi.io/api/v1/users/' + userId,
      type: 'GET', 
      success:function(result){
          //fill data
          document.getElementById("userId").value = result.id;
          document.getElementById("groupname").value = result.groupname;
          document.getElementById("member").value = result.member;
          document.getElementById("name").value = result.name;
          document.getElementById("creator").value = result.creator;
          document.getElementById("createdate").value = result.createdate;
      }
    }); 
}


function reset(){
  document.getElementById("userId").value = "";
    document.getElementById("groupname").value = "";
    document.getElementById("member").value = "";
    document.getElementById("name").value = "";
    document.getElementById("creator").value = "";
    document.getElementById("createdate").value = "";
}


function updateUser(userId){
  var groupname = document.getElementById("groupname").value;
  var member = document.getElementById("member").value;
  var name = document.getElementById("name").value;
  var creator = document.getElementById("creator").value;
  var createdate = document.getElementById("createdate").value;
  
  var user = {
    groupname: groupname,
    member: member,
    name: name,
    creator: creator,
    createdate: createdate

  }
  // gọi api để cập nhật nhân viên 
  $.ajax({
    url: 'https://62163dbb7428a1d2a3605db6.mockapi.io/api/v1/users/' + userId ,
    type: 'PUT',
    data: user,
    async : false,    
    success:function(result){
     
    }
  });
  initTable();
  hideAddNewModal();
}

function saveUser(){
  var userId = document.getElementById("userId").value;
  var groupname = document.getElementById("groupname").value;

  if(userId == null || userId == ""){
      createNewUser();
  }else{
      updateUser(userId);
  }
  showAlertSuccess();
}

function deleteUser(userId){
  var result = confirm("Do you want to delete Group?");
  if(result == true){
      $.ajax({
        url: 'https://62163dbb7428a1d2a3605db6.mockapi.io/api/v1/users/' + userId ,
        type: 'DELETE', 
        async : false,    
        success:function(result){
         
        }
      });

       initTable();
       showAlertSuccess();
  }
}


function showAlertSuccess(){
  $("#alert-success").fadeTo(6600,200).slideUp(2000,function(){
      $("#alert-success").slideUp(5500);
  });
}


function duplicatedAlert() {
  alert("Group name đã tồi tại!");
}